const iconMoon = document.querySelector('.night');
const iconSun = document.querySelector('.day');

const body = document.body;

/**
 * Initial states of the icons
 */
iconMoon.style.display = 'block';
iconSun.style.display = 'none';
let aux=true;
const btnMode = document.querySelector('.btn');
btnMode.addEventListener('click', () => {
    /**
     * TODO - Add/Remove the 'active' class depending on
     *        the Day/Night Mode
     * 
     *   -> the 'active' class is used to change the background
     *      when switching to Day Mode (see body.active in .css)
     * 
     * ++ - try using only one command
     */

        if( aux== true){
            body.classList.toggle("day-mode")
            // changeNighttoDay();
            changeIcon1();
            aux=false;
        }
        else{
            changeIcon2();
            body.classList.toggle("day-mode")
            // changeDaytoNight();
            aux=true;
        }
    });
   
    /**
     * TODO - Create a function to change the text
     *        and call it (e.g. from 'Night Mode' to 'Day Mode')
     * 
     *   - you can pass any parameters to the function
     */
   //   function changeNighttoDay(){
   //      body.classList.add("day-mode");
   //   }   
    
   //   function changeDaytoNight(){
   //      body.classList.remove("day-mode");
   //   }

    /**
     * TODO - Create a function to switch the icon
     * 
     * > Hint - which attribute can you change?
     */



 function changeIcon1(){
    document.getElementsByClassName("text-mode")[0].innerHTML="DayMode";
    document.getElementsByClassName("text-mode")[0].classList.remove("night");
    document.getElementsByClassName("text-mode")[0].classList.add("day");
    document.getElementsByClassName("icon")[1].classList.remove("fa-moon-o","night");
    document.getElementsByClassName("icon")[1].classList.add("fa-sun-o","day");
 }

 function changeIcon2(){
    document.getElementsByClassName("text-mode")[0].innerHTML="NightMode";
    document.getElementsByClassName("text-mode")[0].classList.remove("day");
    document.getElementsByClassName("text-mode")[0].classList.add("night");
    document.getElementsByClassName("icon")[1].classList.remove("fa-sun-o","day");
    document.getElementsByClassName("icon")[1].classList.add("fa-moon-o","night");
 }

